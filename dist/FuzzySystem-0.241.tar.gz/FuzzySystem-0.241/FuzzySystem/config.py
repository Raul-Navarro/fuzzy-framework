default_points = 350
