# fuzzy-framework
Framework to build fuzzy inference systems
