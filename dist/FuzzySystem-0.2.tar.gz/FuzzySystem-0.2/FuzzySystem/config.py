default_points = 100 
