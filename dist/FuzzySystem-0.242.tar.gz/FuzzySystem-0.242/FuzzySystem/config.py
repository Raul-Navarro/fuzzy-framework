'''global configuration file'''

default_points = 350
'''Default number of points to use in sampling and evaluating methods'''
