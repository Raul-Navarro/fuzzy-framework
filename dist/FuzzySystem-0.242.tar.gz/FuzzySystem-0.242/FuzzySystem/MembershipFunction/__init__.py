#from . import membership_function as mf
from .. import config
from .membership_function import MembershipFunction, Trimf, Gaussmf, Trapmf, Sigmoidmf, GBellmf, Logmf, Cauchymf, Tanhmf

